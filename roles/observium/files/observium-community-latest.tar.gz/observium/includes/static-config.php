<?php

// CLEANME remove in r6000

echo("Please remove static-config.inc.php from the bottom of your config.php");

?>

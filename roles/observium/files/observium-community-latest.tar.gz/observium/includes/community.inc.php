<?php

// stub for alerts
function check_entity() {}
function cache_device_alert_table() { return array(); }
function cache_alert_rules() { return array(); }
function get_type_groups() { return array(); }
function get_group_entities() { return array(); }

//EOF

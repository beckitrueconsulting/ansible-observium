<?php

/**
 * Observium
 *
 *   This file is part of Observium.
 *
 * @package    observium
 * @subpackage discovery
 * @copyright  (C) 2006-2014 Adam Armstrong
 *
 */

if (!isset($os))
{
  if (strstr($sysDescr, 'TOSHIBA e-STUDIO')) { $os = 'estudio'; }
}

// EOF
